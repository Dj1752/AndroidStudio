package com.storiespub.scannerapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class QrGenActivity extends AppCompatActivity {
CardView text,address,email,contact,url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_gen);
        getWindow().setStatusBarColor(R.color.black);
        address = findViewById(R.id.AddressQr);
        text = findViewById(R.id.textQr);
        email = findViewById(R.id.EmailQr);
        contact = findViewById(R.id.ContactQr);
        url = findViewById(R.id.URLQr);

        address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(QrGenActivity.this,AddressActivity.class));
            }
        });
        text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(QrGenActivity.this,TextActivity.class));
            }
        });
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(QrGenActivity.this,ContactActivity.class));
            }
        });
        email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(QrGenActivity.this,EmailActivity.class));
            }
        });
        url.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(QrGenActivity.this,URLActivity.class));
            }
        });
    }
}