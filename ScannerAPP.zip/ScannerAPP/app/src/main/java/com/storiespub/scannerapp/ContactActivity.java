package com.storiespub.scannerapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;

import java.util.EnumMap;
import java.util.Map;

public class ContactActivity extends AppCompatActivity {
    private EditText editText;
    private Button generateButton;
    private ImageView qrCodeImageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
        getWindow().setStatusBarColor(R.color.black);
        editText = findViewById(R.id.phone);
        generateButton = findViewById(R.id.generateButton4);
        qrCodeImageView = findViewById(R.id.qrCodeImageView4);
        generateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                generateQRCode();
            }
        });
    }
    private void generateQRCode() {
        String content = editText.getText().toString().trim();
        if (isValidPhoneNumber(content)) {
        if (!content.isEmpty()) {
            int width = 400; // Set your desired QR code width here
            int height = 400; // Set your desired QR code height here

            try {
                Map<EncodeHintType, Object> hints = new EnumMap<>(EncodeHintType.class);
                hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");

                BitMatrix bitMatrix = new MultiFormatWriter().encode(content, BarcodeFormat.QR_CODE, width, height, hints);

                int[] pixels = new int[width * height];
                for (int y = 0; y < height; y++) {
                    for (int x = 0; x < width; x++) {
                        pixels[y * width + x] = bitMatrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF; // Black or white
                    }
                }

                Bitmap qrCodeBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                qrCodeBitmap.setPixels(pixels, 0, width, 0, 0, width, height);

                qrCodeImageView.setImageBitmap(qrCodeBitmap);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        } else {
            Toast.makeText(this, "Invalid phone number", Toast.LENGTH_SHORT).show();

        }
    }
    private boolean isValidPhoneNumber(String phoneNumber) {
        // Remove spaces and dashes to ensure that only digits remain
        phoneNumber = phoneNumber.replaceAll("[\\s-]+", "");

        // Check if the remaining string is exactly 10 digits
        return phoneNumber.matches("\\d{10}");
    }
}